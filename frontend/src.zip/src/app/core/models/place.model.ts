export interface Place {
  id: number;
  name: string;
  country: string;
  city: string;
  description?: string;
  averageRating?: number;
}
