import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../environments/environment';
import { Observable } from 'rxjs';
import { Place } from '../models/place.model';

@Injectable({ providedIn: 'root' })
export class PlacesService {
  private http = inject(HttpClient);
  private base = `${environment.apiBaseUrl}/places`;

  list(): Observable<Place[]> { return this.http.get<Place[]>(this.base); }
  create(dto: { name: string; country: string; city: string; description?: string; }): Observable<Place> {
    return this.http.post<Place>(this.base, dto);
  }
}
