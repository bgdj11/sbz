import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../environments/environment';
import { Observable, tap } from 'rxjs';
import { User } from '../models/user.model';

interface LoginReq { email: string; password: string; }
interface RegisterReq { firstName: string; lastName: string; email: string; password: string; city?: string; }
interface AuthResponse { user: User; message?: string; success?: boolean; }

@Injectable({ providedIn: 'root' })
export class AuthService {
  private http = inject(HttpClient);
  private base = `${environment.apiBaseUrl}/auth`;
  private _currentUser: User | null = null;

  me(): Observable<User> {
    return this.http.get<User>(`${this.base}/me`).pipe(tap(u => this._currentUser = u));
  }

  login(body: LoginReq): Observable<AuthResponse> {
    return this.http.post<AuthResponse>(`${this.base}/login`, body).pipe(
      tap(res => this._currentUser = res.user)
    );
  }

  register(body: RegisterReq): Observable<AuthResponse> {
    return this.http.post<AuthResponse>(`${this.base}/register`, body);
  }

  logout(): Observable<any> {
    return this.http.post(`${this.base}/logout`, {}).pipe(tap(() => this._currentUser = null));
  }

  get currentUser(): User | null { return this._currentUser; }
  get isAdmin(): boolean { return !!this._currentUser?.admin; }
  get isLoggedIn(): boolean { return !!this._currentUser; }
}
