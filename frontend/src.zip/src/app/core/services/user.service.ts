import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../environments/environment';
import { User } from '../models/user.model';
import { Observable } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class UsersService {
  private http = inject(HttpClient);
  private base = `${environment.apiBaseUrl}/users`;

  me(): Observable<User> { return this.http.get<User>(`${this.base}/me`); }
  search(q: string): Observable<User[]> { return this.http.get<User[]>(`${this.base}`, { params: { q } }); }
}
