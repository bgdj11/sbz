import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { PlacesService } from '../../../core/services/places.service';
import { Router } from '@angular/router';

@Component({
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './create-place.component.html'
})
export class CreatePlaceComponent {
  private placesSvc = inject(PlacesService);
  private router = inject(Router);

  name = ''; country = ''; city = ''; description = '';
  error = signal<string | null>(null);

  submit() {
    if (!this.name || !this.country || !this.city) {
      this.error.set('Sva obavezna polja moraju biti popunjena.');
      return;
    }
    this.placesSvc.create({ name: this.name, country: this.country, city: this.city, description: this.description })
      .subscribe({
        next: () => this.router.navigateByUrl('/places'),
        error: (e) => this.error.set(e?.error?.error || 'Greška pri kreiranju mesta')
      });
  }
}
