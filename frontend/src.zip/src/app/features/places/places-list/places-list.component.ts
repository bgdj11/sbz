import { Component, OnInit, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PlacesService } from '../../../core/services/places.service';
import { Place } from '../../../core/models/place.model';

@Component({
  standalone: true,
  imports: [CommonModule],
  templateUrl: './places-list.component.html'
})
export class PlacesListComponent implements OnInit {
  private placesSvc = inject(PlacesService);
  places = signal<Place[]>([]);

  ngOnInit(): void {
    this.placesSvc.list().subscribe(p => this.places.set(p));
  }
}
