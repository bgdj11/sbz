import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, NgForm } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { AuthService } from '../../../core/services/auth.service';

@Component({
  standalone: true,
  selector: 'app-register',
  imports: [CommonModule, FormsModule, RouterLink],
  templateUrl: './register.component.html'
})
export class RegisterComponent {
  private auth = inject(AuthService);
  private router = inject(Router);

  firstName = '';
  lastName = '';
  email = '';
  city = '';
  password = '';
  confirm = '';

  error = signal<string | null>(null);
  loading = signal(false);

  submit(form: NgForm) {
    this.error.set(null);

    if (form.invalid) {
      this.error.set('Popunite sva obavezna polja.');
      return;
    }
    if (this.password !== this.confirm) {
      this.error.set('Lozinke se ne poklapaju.');
      return;
    }

    this.loading.set(true);
    this.auth.register({
      firstName: this.firstName,
      lastName: this.lastName,
      email: this.email,
      password: this.password,
      city: this.city || undefined
    }).subscribe({
      next: () => {
        this.loading.set(false);
        // Posle registracije preusmeri na login (ili direktno login, po želji)
        this.router.navigateByUrl('/login');
      },
      error: (e) => {
        this.loading.set(false);
        this.error.set(e?.error?.error || 'Registracija nije uspela.');
      }
    });
  }
}
