import { Component, OnInit, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PostsService } from '../../../core/services/posts.service';
import { Post } from '../../../core/models/post.model';

@Component({
  standalone: true,
  imports: [CommonModule],
  templateUrl: './friends-feed.component.html'
})
export class FriendsFeedComponent implements OnInit {
  private postsSvc = inject(PostsService);
  posts = signal<Post[]>([]);

  ngOnInit(): void {
    this.postsSvc.friends().subscribe(p => this.posts.set(p));
  }
}
