import { Component, OnInit, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PostsService } from '../../../core/services/posts.service';
import { Post } from '../../../core/models/post.model';

@Component({
  standalone: true,
  imports: [CommonModule],
  templateUrl: './my-posts.component.html'
})
export class MyPostsComponent implements OnInit {
  private postsSvc = inject(PostsService);
  posts = signal<Post[]>([]);

  ngOnInit(): void {
    this.postsSvc.my().subscribe(p => this.posts.set(p));
  }
}
